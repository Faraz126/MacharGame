#pragma once

class BucketLid: public Lids
{
private:

protected:

public:
    BucketLid();
    bool CorrectContainer();
    ~BucketLid();
};
