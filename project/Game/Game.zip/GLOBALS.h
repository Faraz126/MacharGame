#ifndef GLOBALS_H_INCLUDED
#define GLOBALS_H_INCLUDED

bool GAME_QUIT = false;



#endif // GLOBALS_H_INCLUDED
