#include "Screens.h"
#include <SDL.h>
#include <SDL_image.h>

Screens::Screens()
{

}

void Screens::Show(SDL_Renderer* renderer)
{

}




void Screens::HandleEvents(SDL_Event* e, Screens_Node& node)
{

}

void Screens::Update(int frame)
{

}


Screens::~Screens()
{

}
