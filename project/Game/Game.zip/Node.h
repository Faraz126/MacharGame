#pragma once

class Node
{
private:

protected:

public:
    <type> Data;
    Node* next;
};
