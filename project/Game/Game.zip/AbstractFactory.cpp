#include "AbstractFactory.h"

AbstractFactory::AbstractFactory()
{
    //ctor
    mosquito = 0;
}

AbstractFactory::~AbstractFactory()
{
    //dtor
}
