#pragma once

class Bucket : public Container
{
private:

protected:

public:
    Trash();
    Mosquito* breedType(int);
    void Show(SDl_Render*);
    ~Trash();
};
