#pragma once

class Queue
{
private:
    Node* head;

protected:

public:
    Queue()
    void Enqueue(type);
    void Dequeue(type);
    Queue();
};

