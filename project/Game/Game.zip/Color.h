#pragma once

class Color
{
private:
    int r;
    int g;
    int b;
protected:

public:
    Color();
    ~Color();

};
