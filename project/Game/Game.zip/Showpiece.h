#pragma once
#include "Showpiece.h"
#include <SDL.h>
#include <SDL_image.h>
#include "Texture.h"

class Showpiece
{

    SDL_Rect pos;
    int spriteNum;
public:
    Showpiece();
    void Show(SDL_Renderer*);
    void SetPos(int, int, int n = 24);

};
