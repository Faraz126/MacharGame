bool GAME_QUIT = false;
