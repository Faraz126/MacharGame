#pragma once

struct Disease
{
private:
    char* symptoms;

protected:

public:

    Disease();
    Disease(int);
    ~Disease();
};
