#pragma once

class TubLid: public Lids
{
private:

protected:

public:
    TubLid();
    bool CorrectContainer();
    ~TubLid();
};
