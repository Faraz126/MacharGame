#pragma once

class Bucket : public Container
{
private:

protected:

public:
    Bucket();
    Mosquito* breedType(int);
    void Show(SDl_Render*);
    ~Bucket();
};

